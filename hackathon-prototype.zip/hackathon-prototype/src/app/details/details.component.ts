import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HomeService } from '../home.service';
@Component({
    selector: 'app-details',
    templateUrl: './details.component.html',
    styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
    header: string;

    constructor(private homeService: HomeService, private router: Router) {}
    ngOnInit() {
        console.log('Details component loaded =>');
        console.log(this.homeService.selectedLinkName);
        this.header = this.homeService.selectedLinkName;
    }

    goBack() {
        console.log('Going to home page =>');
        this.router.navigate(['/home']);
    }
}