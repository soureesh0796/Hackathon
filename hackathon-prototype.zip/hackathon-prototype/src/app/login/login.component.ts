import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isValidFormSubmitted = false;
  message: string;
  form: NgForm;
  notValid: boolean = false;


  constructor(private router: Router) { }

  ngOnInit() {
    console.log('Login component initiated =>');
  }

  onFormSubmit(form) {
    this.form = form;
    this.loginUser();
  }

  loginUser() {
    console.log("Login successful");
    this.router.navigate(['/home']);
  }
}
