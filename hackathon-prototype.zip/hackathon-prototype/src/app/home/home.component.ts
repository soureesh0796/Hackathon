import { Component, OnInit } from '@angular/core';
import { HomeService } from '../home.service';
@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

    public pieChartLabels = ['Bill Payments', 'Account Summary', 'Credit Card Details', 'Mututal Funds', 'Loans'];
    public pieChartData = [120, 150, 180, 90, 135];
    public pieChartType = 'pie';
    constructor(private homeService: HomeService) { }

    ngOnInit() {
        console.log('Home component initiated =>');
    }

    goTo(name: string) {
        console.log('Link clicked for ' + name);
        this.homeService.selectedLinkName = name;
    }
}

